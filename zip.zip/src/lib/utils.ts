import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  stock: number;
  description: string;
  image_url: string;
}

export interface Booking {
  id: number;
  customer_name: string;
  phone: string;
  vehicle_type: string;
  issue: string;
  booking_date: string;
  status: string;
  created_at: string;
}

export interface Testimonial {
  id: number;
  customer_name: string;
  rating: number;
  comment: string;
  image_before?: string;
  image_after?: string;
  created_at: string;
}
