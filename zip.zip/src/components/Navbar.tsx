import { Link, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { Settings, Menu, X, Phone, Instagram, Facebook } from "lucide-react";
import { useState } from "react";
import { cn } from "@/src/lib/utils";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Tentang Kami", path: "/about" },
  { name: "Booking Servis", path: "/booking" },
  { name: "Sparepart", path: "/products" },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-brand-red rounded-lg flex items-center justify-center rotate-45 group hover:rotate-0 transition-transform duration-300">
              <Settings className="text-white -rotate-45 group-hover:rotate-0 transition-transform duration-300" size={24} />
            </div>
            <span className="text-2xl font-bold tracking-tighter italic">
              ARIES<span className="text-brand-red">PUTRA</span>AUTO
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-brand-red",
                  location.pathname === link.path ? "text-brand-red" : "text-white/70"
                )}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/admin"
              className="p-2 text-white/50 hover:text-white transition-colors"
              title="Admin Dashboard"
            >
              <Settings size={20} />
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white p-2"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <motion.div
        initial={false}
        animate={isOpen ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
        className="md:hidden overflow-hidden bg-black border-b border-white/10"
      >
        <div className="px-4 pt-2 pb-6 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className={cn(
                "block px-3 py-4 text-base font-medium border-b border-white/5",
                location.pathname === link.path ? "text-brand-red" : "text-white"
              )}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/admin"
            onClick={() => setIsOpen(false)}
            className="block px-3 py-4 text-base font-medium text-white/50"
          >
            Admin Dashboard
          </Link>
        </div>
      </motion.div>
    </nav>
  );
}
