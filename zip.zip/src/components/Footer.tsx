import { Link } from "react-router-dom";
import { Phone, Instagram, Facebook, Mail, MapPin, Clock } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-zinc-950 border-t border-white/10 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center space-x-2 mb-6">
              <span className="text-2xl font-bold tracking-tighter italic">
                ARIES<span className="text-brand-red">PUTRA</span>AUTO
              </span>
            </Link>
            <p className="text-zinc-400 max-w-md mb-6">
              Bengkel modern dengan sistem digital dan stok sparepart lengkap. 
              Kami mengutamakan kualitas pelayanan dan transparansi harga untuk kendaraan Anda.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-red transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-red transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://wa.me/628123456789" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-red transition-colors">
                <Phone size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 uppercase tracking-wider">Kontak</h4>
            <ul className="space-y-4 text-zinc-400">
              <li className="flex items-start space-x-3">
                <MapPin className="text-brand-red shrink-0" size={20} />
                <span>Jl. Otomotif No. 123, Jakarta Selatan</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="text-brand-red shrink-0" size={20} />
                <span>+62 812-3456-789</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="text-brand-red shrink-0" size={20} />
                <span>info@ariesputraauto.com</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 uppercase tracking-wider">Jam Operasional</h4>
            <ul className="space-y-4 text-zinc-400">
              <li className="flex items-center justify-between">
                <span>Senin - Jumat</span>
                <span className="text-white">08:00 - 17:00</span>
              </li>
              <li className="flex items-center justify-between">
                <span>Sabtu</span>
                <span className="text-white">08:00 - 15:00</span>
              </li>
              <li className="flex items-center justify-between">
                <span>Minggu</span>
                <span className="text-brand-red font-bold">Tutup</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/5 pt-8 text-center text-zinc-500 text-sm">
          <p>© {new Date().getFullYear()} Aries Putra Auto. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
