import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { Search, Filter, ShoppingCart, AlertCircle, CheckCircle2, XCircle } from "lucide-react";
import { Product } from "@/src/lib/utils";

const categories = ["Semua", "Oli", "Aki", "Kampas Rem", "Ban", "Tools Bengkel"];

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Semua");

  useEffect(() => {
    fetch("/api/products").then(res => res.json()).then(data => setProducts(data));
  }, []);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === "Semua" || p.category === category;
    return matchesSearch && matchesCategory;
  });

  const getStockStatus = (stock: number) => {
    if (stock === 0) return { label: "Kosong", color: "text-red-500", icon: XCircle };
    if (stock < 5) return { label: "Hampir Habis", color: "text-orange-500", icon: AlertCircle };
    return { label: "Tersedia", color: "text-green-500", icon: CheckCircle2 };
  };

  const handleBuy = (product: Product) => {
    const message = `Halo Admin Aries Putra Auto, saya ingin membeli produk:
Nama Produk: ${product.name}
Harga: Rp ${product.price.toLocaleString("id-ID")}
Mohon informasi ketersediaan dan cara pembayarannya.`;
    
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/628123456789?text=${encodedMessage}`, "_blank");
  };

  return (
    <div className="pt-32 pb-24 min-h-screen bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <h1 className="text-5xl font-bold italic mb-4">SPAREPART <span className="text-brand-red">& TOOLS</span></h1>
            <p className="text-zinc-400">Cek ketersediaan stok sparepart original kami secara real-time.</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
              <input
                type="text"
                placeholder="Cari sparepart..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:border-brand-red outline-none transition-all"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full sm:w-48 bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:border-brand-red outline-none appearance-none transition-all"
              >
                {categories.map(c => <option key={c} value={c} className="bg-zinc-900">{c}</option>)}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map((product) => {
            const status = getStockStatus(product.stock);
            return (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-card rounded-2xl overflow-hidden flex flex-col"
              >
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={product.image_url} 
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest">
                    {product.category}
                  </div>
                </div>
                
                <div className="p-5 flex-1 flex flex-col">
                  <h3 className="font-bold text-lg mb-2 line-clamp-2">{product.name}</h3>
                  <p className="text-brand-red font-bold text-xl mb-4">
                    Rp {product.price.toLocaleString("id-ID")}
                  </p>
                  
                  <div className={`flex items-center space-x-2 text-xs font-bold mb-6 ${status.color}`}>
                    <status.icon size={14} />
                    <span>{status.label} ({product.stock})</span>
                  </div>

                  <button
                    onClick={() => handleBuy(product)}
                    disabled={product.stock === 0}
                    className="mt-auto w-full py-3 bg-white/5 hover:bg-brand-red disabled:opacity-50 disabled:hover:bg-white/5 transition-all rounded-xl font-bold flex items-center justify-center space-x-2"
                  >
                    <ShoppingCart size={18} />
                    <span>Beli Sekarang</span>
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <AlertCircle className="mx-auto text-zinc-600 mb-4" size={48} />
            <p className="text-zinc-500 text-xl italic">Produk tidak ditemukan.</p>
          </div>
        )}
      </div>
    </div>
  );
}
