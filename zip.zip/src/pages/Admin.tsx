import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  LayoutDashboard, 
  Package, 
  CalendarCheck, 
  MessageSquare, 
  TrendingUp, 
  Plus, 
  Pencil, 
  Trash2,
  AlertTriangle,
  CheckCircle,
  Clock
} from "lucide-react";
import { Product, Booking, Testimonial } from "@/src/lib/utils";

export default function Admin() {
  const [activeTab, setActiveTab] = useState<"stats" | "products" | "bookings" | "testimonials">("stats");
  const [products, setProducts] = useState<Product[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);

  const fetchData = async () => {
    const [pRes, bRes, sRes] = await Promise.all([
      fetch("/api/products"),
      fetch("/api/bookings"),
      fetch("/api/stats")
    ]);
    setProducts(await pRes.json());
    setBookings(await bRes.json());
    setStats(await sRes.json());
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const method = editingProduct?.id ? "PUT" : "POST";
    const url = editingProduct?.id ? `/api/products/${editingProduct.id}` : "/api/products";
    
    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editingProduct),
    });
    
    setIsModalOpen(false);
    setEditingProduct(null);
    fetchData();
  };

  const handleDeleteProduct = async (id: number) => {
    if (confirm("Hapus produk ini?")) {
      await fetch(`/api/products/${id}`, { method: "DELETE" });
      fetchData();
    }
  };

  return (
    <div className="pt-20 min-h-screen bg-zinc-950 flex">
      {/* Sidebar */}
      <div className="w-64 bg-black border-r border-white/10 p-6 hidden md:block">
        <h2 className="text-xl font-bold italic mb-10 tracking-tighter">
          ADMIN<span className="text-brand-red">PANEL</span>
        </h2>
        <nav className="space-y-2">
          {[
            { id: "stats", label: "Statistik", icon: LayoutDashboard },
            { id: "products", label: "Produk & Stok", icon: Package },
            { id: "bookings", label: "Booking Masuk", icon: CalendarCheck },
            { id: "testimonials", label: "Testimoni", icon: MessageSquare },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id ? "bg-brand-red text-white" : "text-zinc-400 hover:bg-white/5"
              }`}
            >
              <item.icon size={20} />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        {activeTab === "stats" && stats && (
          <div className="space-y-8">
            <h2 className="text-3xl font-bold italic">STATISTIK <span className="text-brand-red">BENGKEL</span></h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="glass-card p-8 rounded-2xl border-l-4 border-l-brand-red">
                <div className="flex justify-between items-start mb-4">
                  <Package className="text-brand-red" size={32} />
                  <span className="text-xs font-bold bg-white/10 px-2 py-1 rounded">TOTAL</span>
                </div>
                <p className="text-zinc-400 text-sm font-bold uppercase tracking-wider mb-1">Total Produk</p>
                <p className="text-4xl font-bold">{stats.totalProducts}</p>
              </div>
              <div className="glass-card p-8 rounded-2xl border-l-4 border-l-blue-500">
                <div className="flex justify-between items-start mb-4">
                  <CalendarCheck className="text-blue-500" size={32} />
                  <span className="text-xs font-bold bg-white/10 px-2 py-1 rounded">AKTIF</span>
                </div>
                <p className="text-zinc-400 text-sm font-bold uppercase tracking-wider mb-1">Total Booking</p>
                <p className="text-4xl font-bold">{stats.totalBookings}</p>
              </div>
              <div className="glass-card p-8 rounded-2xl border-l-4 border-l-orange-500">
                <div className="flex justify-between items-start mb-4">
                  <AlertTriangle className="text-orange-500" size={32} />
                  <span className="text-xs font-bold bg-white/10 px-2 py-1 rounded">KRITIS</span>
                </div>
                <p className="text-zinc-400 text-sm font-bold uppercase tracking-wider mb-1">Stok Menipis</p>
                <p className="text-4xl font-bold">{stats.lowStock}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "products" && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold italic">KELOLA <span className="text-brand-red">PRODUK</span></h2>
              <button 
                onClick={() => { setEditingProduct({}); setIsModalOpen(true); }}
                className="bg-brand-red px-6 py-3 rounded-xl font-bold flex items-center space-x-2 red-glow"
              >
                <Plus size={20} />
                <span>Tambah Produk</span>
              </button>
            </div>

            <div className="glass-card rounded-2xl overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-white/5 border-b border-white/10">
                  <tr>
                    <th className="px-6 py-4 font-bold text-sm uppercase tracking-wider">Produk</th>
                    <th className="px-6 py-4 font-bold text-sm uppercase tracking-wider">Kategori</th>
                    <th className="px-6 py-4 font-bold text-sm uppercase tracking-wider">Harga</th>
                    <th className="px-6 py-4 font-bold text-sm uppercase tracking-wider">Stok</th>
                    <th className="px-6 py-4 font-bold text-sm uppercase tracking-wider text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <img src={p.image_url} className="w-10 h-10 rounded object-cover" />
                          <span className="font-bold">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-zinc-400">{p.category}</td>
                      <td className="px-6 py-4 font-mono">Rp {p.price.toLocaleString("id-ID")}</td>
                      <td className="px-6 py-4">
                        <span className={`font-bold ${p.stock < 5 ? "text-orange-500" : "text-green-500"}`}>
                          {p.stock}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end space-x-2">
                          <button 
                            onClick={() => { setEditingProduct(p); setIsModalOpen(true); }}
                            className="p-2 hover:text-brand-red transition-colors"
                          >
                            <Pencil size={18} />
                          </button>
                          <button 
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-2 hover:text-red-500 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "bookings" && (
          <div className="space-y-8">
            <h2 className="text-3xl font-bold italic">BOOKING <span className="text-brand-red">MASUK</span></h2>
            <div className="grid grid-cols-1 gap-4">
              {bookings.map((b) => (
                <div key={b.id} className="glass-card p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-full bg-brand-red/20 flex items-center justify-center text-brand-red">
                      <Clock size={24} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{b.customer_name}</h3>
                      <p className="text-zinc-400 text-sm">{b.vehicle_type} • {b.phone}</p>
                    </div>
                  </div>
                  <div className="flex-1 max-w-md">
                    <p className="text-sm text-zinc-300 italic">"{b.issue}"</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-brand-red mb-1">{b.booking_date}</p>
                    <span className="text-[10px] uppercase font-bold bg-white/10 px-2 py-1 rounded">
                      {new Date(b.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-900 border border-white/10 rounded-3xl p-8 w-full max-w-lg"
          >
            <h3 className="text-2xl font-bold italic mb-6">
              {editingProduct?.id ? "EDIT" : "TAMBAH"} <span className="text-brand-red">PRODUK</span>
            </h3>
            <form onSubmit={handleSaveProduct} className="space-y-4">
              <input
                required
                placeholder="Nama Produk"
                value={editingProduct?.name || ""}
                onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-brand-red"
              />
              <div className="grid grid-cols-2 gap-4">
                <select
                  value={editingProduct?.category || "Oli"}
                  onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-brand-red"
                >
                  {["Oli", "Aki", "Kampas Rem", "Ban", "Tools Bengkel"].map(c => <option key={c} value={c} className="bg-zinc-900">{c}</option>)}
                </select>
                <input
                  required
                  type="number"
                  placeholder="Harga"
                  value={editingProduct?.price || ""}
                  onChange={(e) => setEditingProduct({ ...editingProduct, price: parseInt(e.target.value) })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-brand-red"
                />
              </div>
              <input
                required
                type="number"
                placeholder="Stok"
                value={editingProduct?.stock || ""}
                onChange={(e) => setEditingProduct({ ...editingProduct, stock: parseInt(e.target.value) })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-brand-red"
              />
              <input
                placeholder="Image URL"
                value={editingProduct?.image_url || ""}
                onChange={(e) => setEditingProduct({ ...editingProduct, image_url: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-brand-red"
              />
              <textarea
                placeholder="Deskripsi"
                rows={3}
                value={editingProduct?.description || ""}
                onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-brand-red"
              />
              <div className="flex space-x-4 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 bg-white/5 hover:bg-white/10 rounded-xl font-bold transition-all"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-brand-red text-white rounded-xl font-bold red-glow transition-all"
                >
                  Simpan
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
