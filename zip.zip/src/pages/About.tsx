import { motion } from "motion/react";
import { Shield, Target, Eye, CheckCircle2 } from "lucide-react";

export default function About() {
  return (
    <div className="pt-32 pb-24 min-h-screen bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero About */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-32">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h1 className="text-5xl font-bold italic mb-8">TENTANG <span className="text-brand-red">KAMI</span></h1>
            <p className="text-xl text-zinc-300 leading-relaxed mb-6">
              "Didirikan dengan semangat profesionalisme dan kepercayaan, Aries Putra Auto hadir sebagai bengkel modern yang mengutamakan kualitas pelayanan dan transparansi harga."
            </p>
            <p className="text-zinc-400 leading-relaxed">
              Kami memahami bahwa kendaraan Anda adalah aset berharga. Oleh karena itu, kami menggabungkan keahlian teknis tradisional dengan sistem manajemen digital modern untuk memastikan setiap servis tercatat dengan akurat dan sparepart yang digunakan selalu terjamin keasliannya.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-brand-red/20 blur-3xl rounded-full" />
            <img 
              src="https://images.unsplash.com/photo-1530046339160-ce3e5b0c7a2f?auto=format&fit=crop&q=80&w=1000" 
              alt="Workshop Interior"
              className="relative rounded-3xl border border-white/10 shadow-2xl"
            />
          </motion.div>
        </div>

        {/* Visi Misi */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-32">
          <div className="glass-card p-10 rounded-3xl border-t-4 border-t-brand-red">
            <Eye className="text-brand-red mb-6" size={48} />
            <h2 className="text-3xl font-bold mb-4 italic">VISI</h2>
            <p className="text-zinc-400 text-lg leading-relaxed">
              Menjadi bengkel terpercaya dan modern dengan sistem digital terintegrasi yang menjadi pilihan utama pemilik kendaraan di Indonesia.
            </p>
          </div>
          <div className="glass-card p-10 rounded-3xl border-t-4 border-t-brand-red">
            <Target className="text-brand-red mb-6" size={48} />
            <h2 className="text-3xl font-bold mb-4 italic">MISI</h2>
            <ul className="space-y-4 text-zinc-400 text-lg">
              <li className="flex items-start space-x-3">
                <CheckCircle2 className="text-brand-red shrink-0 mt-1" size={20} />
                <span>Memberikan pelayanan cepat, jujur, dan transparan.</span>
              </li>
              <li className="flex items-start space-x-3">
                <CheckCircle2 className="text-brand-red shrink-0 mt-1" size={20} />
                <span>Menyediakan sparepart original berkualitas tinggi.</span>
              </li>
              <li className="flex items-start space-x-3">
                <CheckCircle2 className="text-brand-red shrink-0 mt-1" size={20} />
                <span>Mengutamakan kepuasan pelanggan melalui hasil kerja yang presisi.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Values */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold italic mb-12">NILAI <span className="text-brand-red">UTAMA</span></h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Profesional", desc: "Dikerjakan oleh teknisi bersertifikat." },
              { title: "Transparan", desc: "Harga dan proses servis yang jelas." },
              { title: "Amanah", desc: "Kejujuran adalah pondasi bisnis kami." },
            ].map((val, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="p-8 bg-white/5 rounded-2xl border border-white/10"
              >
                <h3 className="text-2xl font-bold text-brand-red mb-2 italic">{val.title}</h3>
                <p className="text-zinc-400">{val.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
