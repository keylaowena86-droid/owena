import { motion } from "motion/react";
import React, { useState } from "react";
import { Calendar, User, Phone, Car, MessageSquare, Send } from "lucide-react";

export default function Booking() {
  const [formData, setFormData] = useState({
    customer_name: "",
    phone: "",
    vehicle_type: "",
    issue: "",
    booking_date: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        // Redirect to WhatsApp
        const message = `Halo Admin Aries Putra Auto, saya ingin booking servis:
Nama: ${formData.customer_name}
No HP: ${formData.phone}
Kendaraan: ${formData.vehicle_type}
Keluhan: ${formData.issue}
Tanggal: ${formData.booking_date}`;
        
        const encodedMessage = encodeURIComponent(message);
        window.open(`https://wa.me/628123456789?text=${encodedMessage}`, "_blank");
        
        setFormData({
          customer_name: "",
          phone: "",
          vehicle_type: "",
          issue: "",
          booking_date: "",
        });
      }
    } catch (error) {
      console.error("Booking error:", error);
    }
  };

  return (
    <div className="pt-32 pb-24 min-h-screen bg-black">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold italic mb-4">BOOKING <span className="text-brand-red">SERVIS</span></h1>
          <p className="text-zinc-400">Jadwalkan servis kendaraan Anda dengan mudah dan cepat.</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-8 rounded-3xl border-t-4 border-t-brand-red"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Nama Lengkap</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    required
                    type="text"
                    value={formData.customer_name}
                    onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                    placeholder="Contoh: Budi Santoso"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Nomor HP / WhatsApp</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    required
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                    placeholder="0812..."
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Jenis Kendaraan</label>
                <div className="relative">
                  <Car className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    required
                    type="text"
                    value={formData.vehicle_type}
                    onChange={(e) => setFormData({ ...formData, vehicle_type: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                    placeholder="Contoh: Toyota Avanza 2022"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Tanggal Booking</label>
                <div className="relative">
                  <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input
                    required
                    type="date"
                    value={formData.booking_date}
                    onChange={(e) => setFormData({ ...formData, booking_date: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Keluhan / Kebutuhan Servis</label>
              <div className="relative">
                <MessageSquare className="absolute left-4 top-4 text-zinc-500" size={20} />
                <textarea
                  required
                  rows={4}
                  value={formData.issue}
                  onChange={(e) => setFormData({ ...formData, issue: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                  placeholder="Ceritakan masalah kendaraan Anda..."
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-5 bg-brand-red text-white font-bold rounded-xl red-glow hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center text-lg"
            >
              <Send className="mr-2" size={20} />
              Konfirmasi & Kirim ke WhatsApp
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
