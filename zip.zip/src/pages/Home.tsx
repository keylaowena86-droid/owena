import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { ChevronRight, Shield, Users, Zap, Star, MapPin, Clock } from "lucide-react";
import { useEffect, useState } from "react";
import { Product, Testimonial } from "@/src/lib/utils";

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    fetch("/api/products").then(res => res.json()).then(data => setProducts(data.slice(0, 3)));
    fetch("/api/testimonials").then(res => res.json()).then(data => setTestimonials(data));
  }, []);

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover opacity-40"
            alt="Workshop Background"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <h1 className="text-6xl md:text-8xl font-bold tracking-tighter italic mb-4 leading-none">
              ARIES<span className="text-brand-red">PUTRA</span>AUTO
            </h1>
            <h2 className="text-2xl md:text-3xl font-bold text-zinc-300 mb-6 uppercase tracking-wide">
              Solusi Servis & Sparepart Terpercaya
            </h2>
            <p className="text-lg text-zinc-400 mb-10 leading-relaxed">
              Bengkel modern dengan sistem digital dan stok sparepart lengkap. 
              Kami hadir untuk memberikan performa terbaik bagi kendaraan Anda.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/booking" 
                className="px-8 py-4 bg-brand-red text-white font-bold rounded-lg red-glow transition-all flex items-center justify-center group"
              >
                Booking Servis Sekarang
                <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/products" 
                className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg backdrop-blur-md transition-all flex items-center justify-center"
              >
                Cek Stok Sparepart
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Keunggulan */}
      <section className="py-24 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Users, title: "Teknisi Profesional", desc: "Tim ahli berpengalaman bertahun-tahun." },
              { icon: Shield, title: "Sparepart Original", desc: "Hanya menyediakan barang asli & berkualitas." },
              { icon: Star, title: "Bergaransi", desc: "Jaminan kepuasan untuk setiap pengerjaan." },
              { icon: Zap, title: "Proses Cepat", desc: "Transparan, jujur, dan efisien." },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="p-8 glass-card rounded-2xl border-l-4 border-l-brand-red"
              >
                <item.icon className="text-brand-red mb-4" size={32} />
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-zinc-400 text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-4xl font-bold italic mb-2">PRODUK <span className="text-brand-red">UNGGULAN</span></h2>
              <p className="text-zinc-400">Sparepart pilihan terbaik untuk performa maksimal.</p>
            </div>
            <Link to="/products" className="text-brand-red font-bold flex items-center hover:underline">
              Lihat Semua <ChevronRight size={20} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {products.map((product) => (
              <motion.div
                key={product.id}
                whileHover={{ y: -10 }}
                className="glass-card rounded-2xl overflow-hidden group"
              >
                <div className="h-64 overflow-hidden relative">
                  <img 
                    src={product.image_url} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-brand-red px-3 py-1 rounded-full text-xs font-bold">
                    {product.category}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                  <p className="text-brand-red font-bold text-lg mb-4">
                    Rp {product.price.toLocaleString("id-ID")}
                  </p>
                  <button className="w-full py-3 bg-white/5 hover:bg-brand-red transition-colors rounded-lg font-bold">
                    Beli Sekarang
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold italic mb-4">APA KATA <span className="text-brand-red">PELANGGAN</span></h2>
            <p className="text-zinc-400">Kepuasan Anda adalah prioritas utama kami.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Andi Wijaya", comment: "Servis sangat cepat dan transparan. Teknisi menjelaskan detail kerusakan dengan jujur.", rating: 5 },
              { name: "Siti Aminah", comment: "Sparepart original dan bergaransi. Mobil jadi enak lagi tarikannya. Recommended!", rating: 5 },
              { name: "Budi Santoso", comment: "Booking online sangat membantu. Datang langsung dikerjakan tanpa antre lama.", rating: 4 },
            ].map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-8 rounded-3xl relative"
              >
                <div className="flex text-brand-red mb-4">
                  {[...Array(t.rating)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                </div>
                <p className="text-zinc-300 italic mb-6">"{t.comment}"</p>
                <p className="font-bold text-white">— {t.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Location */}
      <section className="py-24 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold italic mb-8">LOKASI <span className="text-brand-red">KAMI</span></h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="text-brand-red shrink-0" size={24} />
                  <div>
                    <h4 className="font-bold mb-1">Alamat Lengkap</h4>
                    <p className="text-zinc-400">Jl. Otomotif No. 123, Jakarta Selatan, DKI Jakarta 12345</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Clock className="text-brand-red shrink-0" size={24} />
                  <div>
                    <h4 className="font-bold mb-1">Jam Operasional</h4>
                    <p className="text-zinc-400">Senin - Jumat: 08:00 - 17:00</p>
                    <p className="text-zinc-400">Sabtu: 08:00 - 15:00</p>
                    <p className="text-brand-red font-bold">Minggu: Tutup</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="h-[400px] rounded-3xl overflow-hidden border border-white/10 grayscale hover:grayscale-0 transition-all duration-700">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.273836376512!2d106.816666!3d-6.225!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwMTMnMzAuMCJTIDEwNsKwNDknMDAuMCJF!5e0!3m2!1sen!2sid!4v1631234567890!5m2!1sen!2sid" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen 
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Instagram Feed Placeholder */}
      <section className="py-24 bg-zinc-950 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-12">
          <h2 className="text-4xl font-bold italic mb-4">FOLLOW US ON <span className="text-brand-red">INSTAGRAM</span></h2>
          <p className="text-zinc-400">@ariesputraauto</p>
        </div>
        <div className="flex gap-4 animate-scroll">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="min-w-[300px] h-[300px] bg-zinc-900 rounded-xl overflow-hidden">
              <img 
                src={`https://picsum.photos/seed/insta${i}/400/400`} 
                className="w-full h-full object-cover opacity-60 hover:opacity-100 transition-opacity cursor-pointer"
                alt="Instagram post"
              />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
